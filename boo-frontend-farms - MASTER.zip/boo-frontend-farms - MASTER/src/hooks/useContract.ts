const useContract = (abi, address: string, contractOptions) => {
  return null; // Stubbed for Phantasma - no EVM contract
};

export default useContract;