const useWeb3 = () => {
  return null;
};

export default useWeb3;