import farmsConfig from './farms'

export { farmsConfig }